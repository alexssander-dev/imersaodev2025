function comparar() {
  // Configurações
  const gramasBarra = 90;
  
  // Captura valores
  const gramasOvo = parseFloat(document.getElementById("gramasOvo").value);
  const precoOvo = parseFloat(document.getElementById("precoOvo").value);
  const valorBrinquedo = parseFloat(document.getElementById("brinquedo").value);
  const precoBarra = parseFloat(document.getElementById("tipoBarra").value);

  // Validação
  if (isNaN(gramasOvo) || isNaN(precoOvo)) {
    document.getElementById("resultado").innerHTML = 
      '<p style="color: #ff1b7b; font-weight: bold;">❌ Digite valores válidos para gramas e preço!</p>';
    return;
  }

  // Cálculos
  const qtdBarras = gramasOvo / gramasBarra;
  const precoTotalBarras = qtdBarras * precoBarra;
  const precoOvoAjustado = precoOvo - valorBrinquedo;
  const economiaReais = precoOvoAjustado - precoTotalBarras;
  const economiaPercentual = (economiaReais / precoOvoAjustado) * 100;

  // Formata resultados
  const tipoBarra = precoBarra === 6.99 ? "comuns (Nestlé/Lacta)" : "premium (Milka/Lindt)";
  const temBrinquedo = valorBrinquedo > 0 ? ` (+ brinquedo de R$ ${valorBrinquedo.toFixed(2)})` : '';

  // Monta mensagem
  let mensagem = `
    <p>🍫 <strong>${gramasOvo}g de ovo</strong> = <strong>${qtdBarras.toFixed(1)} barras ${tipoBarra}</strong></p>
    <p>💰 <strong>Ovo:</strong> R$ ${precoOvo.toFixed(2)}${temBrinquedo}</p>
    <p>🛒 <strong>Barras:</strong> R$ ${precoTotalBarras.toFixed(2)}</p>
    <hr>
    <p>💎 <strong>Valor real do chocolate:</strong> R$ ${precoOvoAjustado.toFixed(2)}</p>
  `;

  if (economiaReais > 0) {
    mensagem += `
      <p>📉 <strong>Economia com barras:</strong> R$ ${economiaReais.toFixed(2)} (${economiaPercentual.toFixed(1)}%)</p>
      <p style="color: #1ABC9C; font-weight: bold; font-size: 1.1em; margin-top: 10px;">
      ✨ Você economizaria ${economiaPercentual.toFixed(1)}% comprando barras!</p>
    `;
  } else {
    mensagem += `
      <p>📈 <strong>Vantagem do ovo:</strong> R$ ${Math.abs(economiaReais).toFixed(2)}</p>
      <p style="color: #ff1b7b; font-weight: bold; font-size: 1.1em; margin-top: 10px;">
      ⚠️ O ovo é mais vantajoso!</p>
    `;
  }

  document.getElementById("resultado").innerHTML = mensagem;
}