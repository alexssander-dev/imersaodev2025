# AULA1 _Comparadordepascoa

A Pen created on CodePen.

Original URL: [https://codepen.io/Alexssander-F-Santos/pen/azbQZrM](https://codepen.io/Alexssander-F-Santos/pen/azbQZrM).

